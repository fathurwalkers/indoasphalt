<?php $__env->startPush('css'); ?>
    <style>
        .hero {
            padding: 50px;
            text-align: start;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <h1 class="header ml-auto">FULLY-EXTRACTED <?php echo e($produk->produk_nama); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <!-- Services Section -->
    <section id="services" class="section">
        <div class="container">
            
            <div class="row">
                <div class="col-sm-12s col-md-12s col-lg-12s">
                    <?php echo $produk->produk_keterangan; ?>

                </div>
                
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.development-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathur Walkers\Desktop\app\indoasphalt\resources\views/home/produk/index.blade.php ENDPATH**/ ?>
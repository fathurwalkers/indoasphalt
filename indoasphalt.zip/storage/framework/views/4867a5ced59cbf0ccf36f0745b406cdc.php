<?php $__env->startPush('css'); ?>
    <style>
        .hero {
            padding: 50px;
            text-align: start;
        }

        .gallery img {
            width: 100%;
            height: 200px; /* Sesuaikan tinggi gambar */
            object-fit: cover; /* Memastikan gambar tidak terdistorsi */
            border-radius: 5px; /* Sudut gambar yang sedikit melengkung */
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-content'); ?>
    <h1 class="header ml-auto">PROJECTS</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section id="dokumentasi" class="projects" alt="dokumentasi">
    <div class="container aos-init aos-animate" data-aos="fade-up">

<div class="section-header">
<h2>Dokumentasi</h2>
<p>Kami selalu mengoptimalkan pelayanan kepada setiap customer. Kepuasan dan kepercayaan pelanggan merupakan
    faktor yang sangat penting dan menjadi fokus utama bagi kami.</p>
</div>

<div class="portfolio-isotope" data-portfolio-filter="*" data-portfolio-layout="masonry" data-portfolio-sort="original-order">

<ul class="portfolio-flters aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
    <li data-filter="*" class="filter-active">All</li>

    <li data-filter=".filter-construction">Proyek 1</li>
    <li data-filter=".filter-repairs">Proyek 2</li>
    <li data-filter=".filter-design">Proyek 3</li>
    <li data-filter=".filter-doc">Proyek 4</li>
    <li data-filter=".filter-proyek">Proyek Preservasi</li>

</ul><!-- End Projects Filters -->

<div class="row gy-4 portfolio-container aos-init aos-animate" data-aos="fade-up" data-aos-delay="200" style="position: relative; height: 7100px;">

        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 0px; top: 0px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/1.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 1</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 360px; top: 0px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/1.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 1</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 0px; top: 284px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/1.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 1</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 360px; top: 284px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/1.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 1</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 0px; top: 568px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/1.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 1</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 360px; top: 568px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/2.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 2</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 0px; top: 852px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/2.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 2</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 360px; top: 852px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/2.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 2</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 0px; top: 1136px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/2.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 2</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 360px; top: 1136px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/2.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 2</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 0px; top: 1420px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/3.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 3</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 360px; top: 1420px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/3.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 3</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 0px; top: 1704px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/3.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 3</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 360px; top: 1704px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/3.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 3</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 0px; top: 1988px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/3.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 3</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 360px; top: 1988px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/4.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 4</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 0px; top: 2272px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/4.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 4</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 360px; top: 2272px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/4.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 4</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 0px; top: 2556px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/4.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 4</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 360px; top: 2556px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/4.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 4</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 0px; top: 2840px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/5.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 5</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 360px; top: 2840px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/5.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 5</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 0px; top: 3124px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/5.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 5</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 360px; top: 3124px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/5.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 5</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 0px; top: 3408px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/5.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 5</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 360px; top: 3408px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/6.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 6</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 0px; top: 3692px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/6.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 6</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 360px; top: 3692px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/6.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 6</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 0px; top: 3976px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/6.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 6</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 360px; top: 3976px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/6.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 6</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 0px; top: 4260px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/7.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 7</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 360px; top: 4260px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/7.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 7</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 0px; top: 4544px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/7.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 7</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 360px; top: 4544px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/7.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 7</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 0px; top: 4828px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/7.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 7</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 360px; top: 4828px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/8.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 8</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 0px; top: 5112px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/8.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 8</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 360px; top: 5112px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/8.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 8</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 0px; top: 5396px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/8.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 8</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 360px; top: 5396px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/8.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 8</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 0px; top: 5680px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/9.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 9</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 360px; top: 5680px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/9.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 9</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 0px; top: 5964px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/9.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 9</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 360px; top: 5964px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/9.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 9</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 0px; top: 6248px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/9.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 9</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->


        <div class="col-lg-4 col-md-6 portfolio-item filter-construction" style="position: absolute; left: 360px; top: 6248px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Konawe%20Multi%20Usaha/10.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Konawe Multi Usaha 10</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-repairs" style="position: absolute; left: 0px; top: 6532px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Pyramida%20Raya%20Persada/10.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Pyramida Raya Persada 10</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-design" style="position: absolute; left: 360px; top: 6532px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Serayu%20Putra%20Persada/10.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Serayu Putra Persada 10</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-proyek" style="position: absolute; left: 0px; top: 6816px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/Proyek%20Preservasi%20Jalan%20Dalam%20Kota/10.jpeg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>Proyek Preservasi 10</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

        <div class="col-lg-4 col-md-6 portfolio-item filter-doc" style="position: absolute; left: 360px; top: 6816px;">
            <div class="portfolio-content h-100">
                <img src="https://www.ecoasphalt.id/assets/bahan/PT.%20Berkah%20Bumi%20Ciherang/10.jpg" class="img-fluid img-cek" alt="">
                <div class="portfolio-info">
                    <h4>PT. Berkah Bumi Ciherang 10</h4>
                </div>
            </div>
        </div><!-- End Projects Item -->

</div><!-- End Projects Container -->

</div>

</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.development-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Fathur Walkers\Desktop\app\indoasphalt\resources\views/home/gallery.blade.php ENDPATH**/ ?>
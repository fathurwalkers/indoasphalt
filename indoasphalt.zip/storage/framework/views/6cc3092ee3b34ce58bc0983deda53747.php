<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>INDOASPHALT - Fully Extracted Asphalt Buton</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/dev.css">
    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal2a215807caeeca55d3a2904a75209ef6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a215807caeeca55d3a2904a75209ef6 = $attributes; } ?>
<?php $component = App\View\Components\Development\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('development.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Development\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a215807caeeca55d3a2904a75209ef6)): ?>
<?php $attributes = $__attributesOriginal2a215807caeeca55d3a2904a75209ef6; ?>
<?php unset($__attributesOriginal2a215807caeeca55d3a2904a75209ef6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a215807caeeca55d3a2904a75209ef6)): ?>
<?php $component = $__componentOriginal2a215807caeeca55d3a2904a75209ef6; ?>
<?php unset($__componentOriginal2a215807caeeca55d3a2904a75209ef6); ?>
<?php endif; ?>

    <header id="header" class="hero">
        <div class="container">
            <?php echo $__env->yieldContent('header-content'); ?>
        </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('main-content'); ?>
    </main>

    <footer id="footer" class="footer dark-background">
        <?php if (isset($component)) { $__componentOriginal7a8b44285f8ccc38bdde808572169c48 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a8b44285f8ccc38bdde808572169c48 = $attributes; } ?>
<?php $component = App\View\Components\Development\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('development.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Development\Footer::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a8b44285f8ccc38bdde808572169c48)): ?>
<?php $attributes = $__attributesOriginal7a8b44285f8ccc38bdde808572169c48; ?>
<?php unset($__attributesOriginal7a8b44285f8ccc38bdde808572169c48); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a8b44285f8ccc38bdde808572169c48)): ?>
<?php $component = $__componentOriginal7a8b44285f8ccc38bdde808572169c48; ?>
<?php unset($__componentOriginal7a8b44285f8ccc38bdde808572169c48); ?>
<?php endif; ?>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH C:\Users\Fathur Walkers\Desktop\app\indoasphalt\resources\views/layouts/development-layout.blade.php ENDPATH**/ ?>
<div>
    <nav id="navmenu" class="navmenu">
        <ul>
            <li><a href="index.html" class="active">Home<br></a></li>
            <li><a href="#about">About us</a></li>
            <li><a href="#features">Features</a></li>
            <li><a href="#services">Services</a></li>
            <li class="dropdown"><a href="#"><span>Misc.</span><i class="bi bi-chevron-down toggle-dropdown"></i></a>
                <ul>
                    <li><a href="#">Jobs</a></li>
                    <li><a href="#">Information</a></li>
                </ul>
            </li>
            <li><a href="#footer">Contacts</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
    </nav>
</div>
